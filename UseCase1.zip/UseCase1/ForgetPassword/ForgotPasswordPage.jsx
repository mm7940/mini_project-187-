import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import ScImage1 from "../Images/ResetPass.png"; 
import "./ForgotPasswordPage.css";

function ForgotPasswordPage() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    token: "",
    newPassword: "",
  });
  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage("");

    try {
      const response = await fetch("http://localhost:8080/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setMessage("✅ Password reset successfully! Redirecting to login...");
        setTimeout(() => navigate("/login"), 2000);
      } else {
        const data = await response.json();
        setMessage(data.message || "❌ Failed to reset password.");
      }
    } catch (error) {
      setMessage("⚠️ Server error. Please try again later.");
    }
  };

  return (
    <div className="auth-page forgot-page">
      <div className="auth-container">
        {/* ===== IMAGE SECTION ===== */}
        <div className="auth-image-section">
          <img
            src={ScImage1}
            alt="Standard Chartered Bank"
            className="auth-image"
          />
        </div>

        {/* ===== FORM SECTION ===== */}
        <div className="auth-form-section">
          <div className="auth-header">
            <h1>Reset Your Password</h1>
            <p>Enter your verification token and your new password below.</p>
            <button className="back-btn" onClick={() => navigate("/")}>
              ← Back to Home
            </button>
          </div>

          <form onSubmit={handleSubmit} className="auth-form">
            <div className="form-group">
              <label htmlFor="token">Verification Token</label>
              <input
                type="text"
                id="token"
                name="token"
                placeholder="Enter the token sent to your email"
                value={formData.token}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="newPassword">New Password</label>
              <input
                type="password"
                id="newPassword"
                name="newPassword"
                placeholder="Enter your new password"
                value={formData.newPassword}
                onChange={handleChange}
                required
              />
            </div>

            <button type="submit" className="submit-btn">
              🔒 Reset Password
            </button>
          </form>

          {message && <p className="message">{message}</p>}

          <div className="form-footer">
            <p>
              Remembered your password?{" "}
              <span className="switch-form" onClick={() => navigate("/login")}>
                Login here
              </span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ForgotPasswordPage;
